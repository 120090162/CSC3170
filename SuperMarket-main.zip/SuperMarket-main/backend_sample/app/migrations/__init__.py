import pymysql

pymysql.install_as_MySQLdb()
import pymysql

pymysql.install_as_MySQLdb()
import pymysql

pymysql.install_as_MySQLdb()
import pymysql

pymysql.install_as_MySQLdb()
import pymysql

pymysql.install_as_MySQLdb()
import pymysql

pymysql.install_as_MySQLdb()
